from calibration.calibration import ma_fonction

print(ma_fonction())